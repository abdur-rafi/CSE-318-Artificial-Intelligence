package PHeuristics;

public interface CalculatePenalty {
    public long penalty();    
    public double averagePenalty();
}
