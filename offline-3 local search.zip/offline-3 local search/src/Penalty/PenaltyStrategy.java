package Penalty;

public interface PenaltyStrategy {
    long penalty(int a, int b);
}
