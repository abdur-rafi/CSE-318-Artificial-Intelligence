public interface Heuristic {
    int calc(int[][] grid);
}
